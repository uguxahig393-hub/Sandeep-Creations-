# Sandeep's Creations — Online Store

## GitHub Pages setup
1. Create a new GitHub repository (for example: `sandeep-creations`).
2. Upload `index.html` and the three `product-*.jpg` files from this folder.
3. Open the repository's **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main` and `/ (root)`, then Save.
5. GitHub will give you a website URL.

## WhatsApp
Orders are sent to WhatsApp number **8448941629**.

## Product
Pearl Letter Keychains — **₹199 per piece**.
Delivery: **Delhi**.

To change the price, shop name, phone number, or product text, edit `index.html`.
